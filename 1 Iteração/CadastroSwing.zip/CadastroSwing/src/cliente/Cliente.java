package cliente;

public class Cliente {
    private String nome;
    private String sobrenome;
    private String cpf;
    private String telefone;
    private String cep;
    private String logradouro;
    private String numeroResidencia;
    private String email;
    private String senha;

    public Cliente(String nome, String sobrenome, String cpf, String telefone, String cep, String logradouro, String numeroResidencia, String email, String senha) {
        setNome(nome);
        setSobrenome(sobrenome);
        setCpf(cpf);
        setTelefone(telefone);
        setCep(cep);
        setLogradouro(logradouro);
        setNumeroResidencia(numeroResidencia);
        setEmail(email);
        setSenha(senha);
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setNumeroResidencia(String numeroResidencia) {
        this.numeroResidencia = numeroResidencia;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCep() {
        return cep;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public String getNumeroResidencia() {
        return numeroResidencia;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }
}
