package cliente;

import java.sql.*;

public class ClienteDAO {
    private Conexao db;

    public ClienteDAO() {
        db = new Conexao();
    }

    // Insere nova tupla de cliente
    public boolean cadastrar(Cliente c) {
        db.conectar("jdbc:sqlite:users.db");
        
        String sql = "INSERT INTO users(nome,sobrenome,cpf,telefone,cep,logradouro,numeroResidencia,email,senha) VALUES(?,?,?,?,?,?,?,?,?)";
        if (cadastrado(c.getCpf())) //verifica se o usuário já está cadastrado, caso esteja, retorna falso e não realiza o cadastro
        {
            return false;
        }
        try (PreparedStatement pstmt = db.getConn().prepareStatement(sql)) { //Insere nova tupla caso o usuário não esteja cadastrado e retornado true
            pstmt.setString(1, c.getNome());
            pstmt.setString(2, c.getSobrenome());
            pstmt.setString(3, c.getCpf());
            pstmt.setString(4, c.getTelefone());
            pstmt.setString(5, c.getCep());
            pstmt.setString(6, c.getLogradouro());
            pstmt.setString(7, c.getNumeroResidencia());
            pstmt.setString(8, c.getEmail());
            pstmt.setString(9, c.getSenha());
            pstmt.executeUpdate();
            
            db.desconectar();
            return true;
        } catch (SQLException e) { //Mensagem de erro de SQL
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    // Verifica se o usuário fez autenticação correta e se ele existe, caso a autenticação tenha sucesso, retorna true, caso contrário, retorna false
    public boolean loga(String email, String senha) {
        try {
            String sql = "SELECT senha FROM users WHERE email = ?";
            PreparedStatement pstmt = db.getConn().prepareStatement(sql);
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            if (!rs.next()) {
                return false;
            } else 
                return rs.getString("senha").equals(senha);
        } catch (SQLException e) {
            ;
        };
        return false;
    }
    
    //Função auxiliar para verificar se o usuário está cadastrado
    private boolean cadastrado(String cpf) { 
        try {
            String sql = "SELECT nome FROM users WHERE cpf = ?";
            PreparedStatement pstmt = db.getConn().prepareStatement(sql);
            pstmt.setString(1, cpf);
            ResultSet rs = pstmt.executeQuery();
            
            return rs.next();
        } catch (SQLException e) {
            ;
        };
        return false;
    }

    public Conexao getDb() {
        return db;
    }
}
