package cliente;

import java.sql.*;

class Conexao {
    private Connection conn;

    public void conectar(String nomeDB) {
        try {
            setConn(DriverManager.getConnection(nomeDB));
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    public void desconectar() {
        try {
            if(getConn().isClosed() == false)
                getConn().close();
        } catch (SQLException ex) {
            System.out.print("SQLException: ");
            System.out.println(ex.getMessage());
        }
    }
    
    public Statement criarStatement() {
        try {
            return getConn().createStatement();
        } catch (SQLException ex) {
            return null;
        }
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    public Connection getConn() {
        return conn;
    }
}
