package cliente;

import java.sql.SQLException;
import java.sql.Statement;

public class CriarBancoSQLite {
    private final Conexao conexao;

    public CriarBancoSQLite(Conexao conexao) {
        this.conexao = conexao;
    }
    
    public void criarTabelaPessoa() {
        String sql = "CREATE TABLE IF NOT EXISTS users (" +
                    "nome TEXT DEFAULT 40," +
                    "sobrenome TEXT DEFAULT 65," +
                    "cpf TEXT DEFAULT 14 UNIQUE," +
                    "telefone TEXT DEFAULT 14," +
                    "cep TEXT DEFAULT 10," +
                    "logradouro TEXT DEFAULT 85," +
                    "numeroResidencia INTEGER DEFAULT 6," +
                    "email TEXT DEFAULT 85," +
                    "senha TEXT DEFAULT 85," +
                    "PRIMARY KEY(\"cpf\") )";
        
        try {
            conexao.conectar("jdbc:sqlite:users.db");
            
            Statement stmt = conexao.criarStatement();
            stmt.execute(sql);
        } catch (SQLException ex) {
            System.out.print("SQLException: ");
            System.out.println(ex.getMessage());
        } finally {
            if(conexao.getConn() != null)
                conexao.desconectar();
        }
    }
}
