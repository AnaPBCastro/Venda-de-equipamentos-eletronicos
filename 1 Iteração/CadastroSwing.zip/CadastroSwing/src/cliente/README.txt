Para compilar e executar sua classe com o SQLITE3 use as seguintes linhas no cmd:

javac nomedasuaclasse.java
java -classpath ".;sqlite-jdbc-3.36.0.3.jar"  nomedasuaclasseclasse